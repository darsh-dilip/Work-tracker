import { useState } from 'react'
import { CONSTITUTIONS, ROLES } from '../constants.js'
import { generateTasks } from '../utils/taskGenerator.js'
import { addClient, bulkAddTasks } from '../hooks/useFirestore.js'
import { logClientOnboarded } from '../utils/auditLog.js'
import { Label, Alert } from '../components/UI.jsx'

export const AddClientPage = ({ users, currentUser, onBack, onSuccess }) => {
  const [form, setForm] = useState({
    name:'',constitution:'Private Limited',gstin:'',pan:'',tan:'',
    gstApplicable:false,gstFreq:'monthly',tdsApplicable:false,
    ptMH:false,ptKA:false,itApplicable:false,auditCase:false,
    advanceTax:false,accounting:false,caCertificates:false,
    assignedTo:'',fy:'2025-26',
  })
  const [error,   setError]   = useState('')
  const [saving,  setSaving]  = useState(false)
  const [success, setSuccess] = useState(false)

  const set = (k,v) => setForm(f=>({...f,[k]:v}))
  const eligible = users.filter(u=>['team_leader','executive','intern'].includes(u.role))

  const taskCount = [
    form.gstApplicable&&(form.gstFreq==='monthly'?37:13),
    form.tdsApplicable&&16, form.ptMH&&13, form.ptKA&&2,
    form.itApplicable&&1, form.advanceTax&&4, form.accounting&&12, form.caCertificates&&1,
  ].filter(Boolean).reduce((a,b)=>a+b,0)

  const submit = async () => {
    if (!form.name.trim())  { setError('Client name is required.'); return }
    if (!form.assignedTo)   { setError('Please assign to a team member.'); return }
    setSaving(true); setError('')
    try {
      const ref   = await addClient(form)
      const tasks = generateTasks({ ...form, id:ref.id }, form.assignedTo, form.fy)
      await bulkAddTasks(tasks)
      if (currentUser) await logClientOnboarded({ ...form, id:ref.id }, currentUser)
      setSuccess(true)
      setTimeout(()=>{ onSuccess(); onBack() }, 1400)
    } catch(e) { setError(e.message) } finally { setSaving(false) }
  }

  const Toggle = ({ k, label }) => (
    <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 12px',background:'var(--surface2)',borderRadius:8,border:'1px solid var(--border)' }}>
      <span style={{ fontSize:13,color:'var(--text)',fontWeight:500 }}>{label}</span>
      <label className="toggle"><input type="checkbox" checked={form[k]} onChange={e=>set(k,e.target.checked)}/><span className="slider"/></label>
    </div>
  )

  return (
    <div className="fade-up" style={{ padding:'24px 28px',maxWidth:700 }}>
      <button className="btn btn-ghost btn-sm" onClick={onBack} style={{ marginBottom:16 }}>← Back</button>
      <div style={{ fontSize:20,fontWeight:800,color:'var(--text)',marginBottom:4 }}>Onboard New Client</div>
      <div style={{ fontSize:13,color:'var(--text2)',marginBottom:22 }}>Tasks for the full financial year will be auto-created.</div>

      {success && <Alert type="success" message="✓ Client onboarded! Tasks created. Redirecting…"/>}

      <div style={{ display:'flex',flexDirection:'column',gap:18 }}>
        <div className="card" style={{ padding:18 }}>
          <div style={{ fontWeight:700,fontSize:13,color:'var(--text)',marginBottom:12 }}>📋 Basic Information</div>
          <div className="grid-2" style={{ gap:10 }}>
            <div style={{ gridColumn:'1/-1' }}><Label>Client / Business Name *</Label><input placeholder="e.g. Sharma Enterprises Pvt Ltd" value={form.name} onChange={e=>set('name',e.target.value)}/></div>
            <div><Label>Constitution *</Label><select value={form.constitution} onChange={e=>set('constitution',e.target.value)}>{CONSTITUTIONS.map(c=><option key={c}>{c}</option>)}</select></div>
            <div><Label>Financial Year</Label><select value={form.fy} onChange={e=>set('fy',e.target.value)}><option value="2025-26">FY 2025–26</option><option value="2024-25">FY 2024–25</option></select></div>
            <div><Label>GSTIN</Label><input placeholder="27AAAAA0000A1Z5" value={form.gstin} onChange={e=>set('gstin',e.target.value.toUpperCase())}/></div>
            <div><Label>PAN</Label><input placeholder="AAAAA0000A" value={form.pan} onChange={e=>set('pan',e.target.value.toUpperCase())}/></div>
            <div><Label>TAN</Label><input placeholder="ABCD01234E" value={form.tan} onChange={e=>set('tan',e.target.value.toUpperCase())}/></div>
            <div><Label>Assign To *</Label>
              <select value={form.assignedTo} onChange={e=>set('assignedTo',e.target.value)}>
                <option value="">-- Select Team Member --</option>
                {eligible.map(u=><option key={u.id} value={u.id}>{u.name} ({ROLES[u.role]})</option>)}
              </select>
            </div>
          </div>
        </div>

        <div className="card" style={{ padding:18 }}>
          <div style={{ fontWeight:700,fontSize:13,color:'var(--text)',marginBottom:12 }}>⚖️ Compliance Package</div>
          <div style={{ display:'flex',flexDirection:'column',gap:6 }}>
            <Toggle k="gstApplicable" label="GST (GSTR-1, GSTR-2B Recon, GSTR-3B, GSTR-9)"/>
            {form.gstApplicable && (
              <div style={{ background:'var(--surface3)',borderRadius:8,padding:'10px 12px',border:'1px solid var(--border2)',marginTop:-2 }}>
                <Label>Filing Frequency</Label>
                <div style={{ display:'flex',gap:8,marginTop:4 }}>
                  {[['monthly','Monthly (11th)'],['quarterly','Quarterly QRMP (13th)']].map(([v,l])=>(
                    <button key={v} onClick={()=>set('gstFreq',v)} className={`btn btn-sm ${form.gstFreq===v?'btn-primary':'btn-ghost'}`}>{l}</button>
                  ))}
                </div>
              </div>
            )}
            <Toggle k="tdsApplicable"  label="TDS (Monthly Payments + Quarterly Returns)"/>
            <Toggle k="ptMH"           label="PT Maharashtra (Monthly + Annual Return)"/>
            <Toggle k="ptKA"           label="PT Karnataka (Annual)"/>
            <Toggle k="itApplicable"   label="Income Tax Filing"/>
            {form.itApplicable && (
              <div style={{ background:'var(--surface3)',borderRadius:8,padding:'10px 12px',border:'1px solid var(--border2)',marginTop:-2,display:'flex',alignItems:'center',justifyContent:'space-between' }}>
                <span style={{ fontSize:13,color:'var(--text)' }}>Audit Case? (due Oct 31)</span>
                <label className="toggle"><input type="checkbox" checked={form.auditCase} onChange={e=>set('auditCase',e.target.checked)}/><span className="slider"/></label>
              </div>
            )}
            <Toggle k="advanceTax"     label="Advance Tax (Quarterly)"/>
            <Toggle k="accounting"     label="Accounting (Monthly)"/>
            <Toggle k="caCertificates" label="CA Certificates"/>
          </div>
        </div>

        {taskCount>0 && (
          <div style={{ background:'#5b8dee15',border:'1px solid #5b8dee30',borderRadius:10,padding:'12px 16px' }}>
            <div style={{ fontSize:13,color:'var(--accent)',fontWeight:700 }}>✓ Preview</div>
            <div style={{ fontSize:12,color:'var(--text2)',marginTop:4 }}>
              ~<strong style={{ color:'var(--text)' }}>{taskCount} tasks</strong> will be created for FY {form.fy}
              {form.assignedTo&&` assigned to ${users.find(u=>u.id===form.assignedTo)?.name||'selected member'}`}.
            </div>
          </div>
        )}

        {error && <Alert message={error}/>}

        <div style={{ display:'flex',gap:10 }}>
          <button className="btn btn-primary" style={{ flex:1 }} onClick={submit} disabled={saving||success}>
            {saving?'Creating tasks…':'🚀 Onboard Client & Create Tasks'}
          </button>
          <button className="btn btn-ghost" onClick={onBack}>Cancel</button>
        </div>
      </div>
    </div>
  )
}
